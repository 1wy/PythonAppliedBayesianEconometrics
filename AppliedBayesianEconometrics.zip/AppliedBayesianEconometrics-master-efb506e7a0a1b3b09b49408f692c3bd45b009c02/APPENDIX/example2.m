%create a matrix of zeros
X=zeros(10,10);
%create a matrix of ones
Y=ones(10,20);
%create an identity matrix
I=eye(10);
%create a 10 by 10 matrix from N(0,1)
N=randn(10,10);
%create a 10 by 10 matrix from U(0,1)
U=rand(10,10);