%read in data from an excel file
[data,names]=xlsread('\data\data.xls');