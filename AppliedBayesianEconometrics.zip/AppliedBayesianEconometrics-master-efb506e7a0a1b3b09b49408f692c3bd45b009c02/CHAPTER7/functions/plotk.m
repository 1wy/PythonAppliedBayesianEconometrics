function [ h ] = plotk( t,x )
h=plot(t,x,'k','LineWidth',2);

end

