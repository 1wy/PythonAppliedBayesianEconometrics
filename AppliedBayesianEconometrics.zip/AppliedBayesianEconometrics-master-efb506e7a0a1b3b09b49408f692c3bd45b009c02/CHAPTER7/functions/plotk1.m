function [ h ] = plotk1( t,x )
h=plot(t,x(:,1),'k','LineWidth',2);
% hold on
% h=plot(t,x(:,2),'.k','LineWidth',0.5);
% hold on
% h=plot(t,x(:,3),'.k','LineWidth',0.5);
end

